dpkg-deb --build arducam-iqfiles
