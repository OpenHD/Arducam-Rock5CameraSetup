#!/bin/bash
resolution=$1

if [ -z "$resolution" ]; then
echo "Please set resolution!"
exit
fi
target_folder="/etc/iqfiles"

# Run  media-ctl -p commend and save the message to output
output=$(media-ctl -p)

# get "pivariety" line
line=$(echo "$output" | grep -oE 'pivariety_[0-9a-fA-F]{4}')
if [ -z "$line" ]; then
	line=$(echo "$output" | grep -oE 'imx519')
fi
# Delete uniq
unique_name=$(echo "$line" | sort | uniq)
case $unique_name in
  "pivariety_0477")
    echo "current module is pivariiety_0477"
    media-ctl -d /dev/media0 --set-v4l2 '"m00_b_pivariety_0477 3-000c":0 [fmt:SRGGB10_1X10/'"$resolution"']'
    source_folder="$(cd "$(dirname "$0")" && pwd)/iqfiles/arducam-pivariety"
    echo $source_folder
    target_file="pivariety_IQ_default.json"
    case $resolution in
	    "4056x3040")
    		source_file="pivariety_imx477p_12MP_default.json"
		;;
	    "3840x2160")
    		source_file="pivariety_imx477p_8MP_default.json"
	        ;;
	    "1920x1080")
    		source_file="pivariety_imx477p_1080P_default.json"
	        ;;	    
	    *)
		echo "Not support resolution"
		;;
    esac
    ;;
   "imx519")
    echo "current module is imx519"
    media-ctl -d /dev/media0 --set-v4l2 '"m00_b_imx519 3-001a":0 [fmt:SRGGB10_1X10/'"$resolution"']'
    source_folder="$(cd "$(dirname "$0")" && pwd)/iqfiles/imx519"
    echo $source_folder
    target_file="imx519_IQ_default.json"
    case $resolution in

	    "4656x3496")
    		source_file="imx519_16MP_default.json"
		;;
	    "3840x2160")
    		source_file="imx519_8MP_default.json"
	        ;;
	    "1920x1080")
    		source_file="imx519_1080P_default.json"
	        ;;	    
	    *)
		echo "Not support resolution"
		;;
    esac
   ;;	   
esac


output=$(media-ctl -p)

# Find target file 
result=$(find "$source_folder" -type f -name "$source_file")
if [ -n "$result" ]; then
  sudo cp $result $target_folder/$target_file
  echo "Copy $result to $target_folder/$target_file"
else
  echo "Can't find $source_file"
fi

# Restart rkaiq_3A_server

target_process="rkaiq_3A_server"
pid=$(pgrep "$target_process")
if [ -z "$pid" ]; then
  echo "Can't find $target_process"
else
  echo "Find $target_process (PID: $pid)"
  sudo pkill  "$target_process"
  echo "$target_process (PID: $pid) is killed"
fi
rkaiq_3A_server &

echo "restart rkaiq_3A_server"

export DISPLAY=:0


